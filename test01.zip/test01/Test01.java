package test01;

/**
 * IMPORTANT:
 * +++++++++++++++++++++++++++++++++
 * - TestCode: ROW|COLUMN 
 * +++++++++++++++++++++++++++++++++
 * - Open your editor in full-screen mode.
 * - Implement your solution in this class.
 * - If not told otherwise, using inbuilt methods like Math.pow is not allowed.
 * - You are not allowed to search the internet for code snippets.
 * - You are not allowed to copy code from other projects (assignments, lecture script, …)
 * - Keep the current style guidelines in mind. If violated, there will be a reduction of max 2 points.
 * - Push your solution to your Git project
 */
public class Test01 
{	
	/**
	 * The main method contains some test cases.
	 * These test cases are not exhaustive. Carefully check edge cases by yourself.
	 * @param args
	 */
	public static void main(String[] args)
	{
		//++++++++++++++++ 
        //TESTCASE Task 1:
        //++++++++++++++++
        System.out.println(andGate(false, false)); // false
        System.out.println(andGate(false, true));  // false
        System.out.println(andGate(true, false));  // false
        System.out.println(andGate(true, true));   // true
        
        
		//++++++++++++++
        //Initialization
        //++++++++++++++		
        int[] array = {1,2,3,4,5,6,7,8,9};
		
        //++++++++++++++++ 
        //TESTCASE Task 2:
        //++++++++++++++++
        printArray(array); // 1 2 3 4 5 6 7 8 9
		
        //++++++++++++++++ 
        //TESTCASE Task 3:
        //++++++++++++++++		
        System.out.println(getIndex(array, 2)); //  1
        System.out.println(getIndex(array, 0)); // -1
        
        //++++++++++++++++ 
        //TESTCASE Task 4:
        //++++++++++++++++        
        System.out.println(arraySum(array)); // 45
        
        //++++++++++++++++ 
        //TESTCASE Task 5:
        //++++++++++++++++
        int[] arrayLonger = addToArray(array, 10);
        printArray(arrayLonger); // 1 2 3 4 5 6 7 8 9 10
        
        //++++++++++++++++ 
        //TESTCASE Task 6:
        //++++++++++++++++
        char[] word = {'I',' ','l','o','v','e',' ','p','r','o','g','r','a','m','m','i','n','g'};
        System.out.println(getVowels(word)); // Ioeoai
	}	
	
	//*******************************
	//TASK 1: boolean logic (1 point)
	//*******************************
	public static boolean andGate(boolean switchA, boolean switchB)
	{
		//TODO: Implement this method.
		/*
		 * This method should simulate the boolean operator &&. 
		 * In your solution, you are NOT allowed to use the boolean operators (&&, &, ||, |, !). 
		 */	
		return false;
	}
	
	
	//****************************************
	//Task 2: one-dimensional arrays (1 point)
	//****************************************
	public static void printArray(int[] array)
	{
		//TODO: Implement this method.
		/*
		 * This method should print a one-dimensional integer array to the console. 
		 * Each entry should be in the same line separated by a blank space. 
		 * 
		 * hint: Have a look at the function System.out.print();
		 */	
	}
	
	
	//*******************************************
	//Task 3: one-dimensional arrays (1.5 points)
	//*******************************************
	public static int getIndex(int[] array, int value) 
	{
		//TODO: Implement this method.
		/*
		 * Returns the index of the first occurrence of the specified element (value) 
		 * in this array; or -1 if this array does not contain the element.
		 * 
		 */	
		return 0;
	}
	
	
	//*******************************************
	//Task 4: one-dimensional arrays (1.5 points)
	//*******************************************
	public static int arraySum(int[] array)
	{
		//TODO: Implement this method.
		/*
		 * This method returns the sum of all elements in this array; 
		 * e.g., [1, 2, 3] = 1 + 2 + 3 = 6 
		 * 
		 */	
		return 0;
	}

	
	//*****************************************
	//Task 5: one-dimensional arrays (2 points)
	//*****************************************	
	public static int[] addToArray(int[] array, int value)
	{
		//TODO: Implement this method.
		/*
		 * Increase the length of the array and add the element (value) 
		 * to the last index position.
		 * 
		 * You should implement the following steps:
		 * 1.	Initialize an empty one-dimensional array.
		 * 2.	Add the element to the new array.
		 * 3.	Return the new (longer) array.
		 */
		return array;
	}
	
	
	//*****************************************
	//Task 6: one-dimensional arrays (3 points)
	//*****************************************	
	public static char[] getVowels(char[] array)
	{
		//TODO: Implement this method.
		/*
		 * Return only the vowels (a, A, e, E, i, I, o, O, u, U) from the array. 
		 * 
		 * You should implement the following steps:
		 * 1.	Initialize an empty one-dimensional array.
		 * 2.	Add the vowels to the array.
		 * 3.	Return the new array that only contains vowels.
		 */
		return array;
	}
}
